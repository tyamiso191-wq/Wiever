# Bu projede minifyEnabled = false olduğu için özel bir kurala gerek yok.
