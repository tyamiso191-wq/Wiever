package com.jarvis.gamewrapper

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/**
 * Jarvis'in ürettiği oyunu (app/src/main/assets/index.html) tam ekran bir
 * WebView içinde açan, tek ekranlık basit bir "oyun kutusu".
 *
 * Kullanım: Jarvis'ten aldığın zip'teki index.html dosyasıyla, bu projenin
 * app/src/main/assets/index.html dosyasının içeriğini DEĞİŞTİR (üstüne
 * kaydet / yapıştır), sonra bu klasörü GitHub'a yükleyip Actions'ın
 * derlemesini bekle. Ayrıntılı adımlar bu projenin README.md dosyasında.
 */
class MainActivity : AppCompatActivity() {

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Tam ekran, sistem çubukları gizli (oyun deneyimi için).
        WindowCompat.setDecorFitsSystemWindows(window, false)

        val webView = WebView(this)
        setContentView(webView)

        hideSystemBars(webView)
        window.decorView.setOnSystemUiVisibilityChangeListener {
            hideSystemBars(webView)
        }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            loadWithOverviewMode = true
            useWideViewPort = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
        }
        webView.webViewClient = WebViewClient()

        // Oyunun kendi index.html'i her zaman assets içinden yüklenir --
        // internet gerekmez, tamamen cihaz üzerinde çalışır.
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun hideSystemBars(view: View) {
        val controller = WindowInsetsControllerCompat(window, view)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars(window.decorView)
    }
}
