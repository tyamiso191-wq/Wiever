# Oyun APK Sarmalayıcı

Jarvis'in sana verdiği `index.html` (oyunun kendisi) dosyasını gerçek bir
**.apk** dosyasına çeviren, bilgisayarsız, sadece telefondan kullanılabilen
hazır bir kabuk proje. Bilgisayar/Android Studio GEREKMEZ — her şey GitHub
Actions üzerinde otomatik derlenir.

---

## Nasıl çalışır

Bu proje tek yaptığı şey: `app/src/main/assets/index.html` dosyasını açılışta
tam ekran bir WebView'da göstermek. Yani senin oyunun sadece bu tek dosyanın
içine girip GitHub'a yüklenmesi yeterli.

---

## Adımlar (telefondan)

### 1. Bu projeyi GitHub'a yükle
1. https://github.com → hesabın yoksa **Sign up**
2. Sağ üstte **+** → **New repository**
3. İsim: `OyunApk` (istediğin isim olabilir) → **Public** → **Create repository**
4. **uploading an existing file** (ya da Add file → Upload files)
5. Bu klasördeki **TÜM dosya ve klasörleri** seç ve yükle — **`.github` klasörünü
   unutma**, o olmadan otomatik derleme çalışmaz (bazı telefon dosya
   seçicileri gizli/nokta ile başlayan klasörleri göstermeyebilir; öyleyse
   klasörü yüklemeden önce görünür hale getirmen ya da bilgisayarsız bir zip
   yükleme/GitHub mobil uygulaması üzerinden yüklemen gerekebilir)
6. **Commit changes**

### 2. Jarvis'in oyununu içine koy
1. Jarvis'ten aldığın oyun zip'ini aç, içindeki `index.html`'in TAMAMINI
   kopyala.
2. GitHub'daki reponda `app/src/main/assets/index.html` dosyasını aç
   (kalem/edit ikonuna dokun), içindeki her şeyi sil, kopyaladığın oyun
   kodunu yapıştır.
3. **Commit changes** (bu commit otomatik olarak derlemeyi de başlatır).

### 3. APK'yı indir
1. Reponda **Actions** sekmesine gir.
2. **Build APK** işinin yeşil tik almasını bekle (genelde 2-5 dk).
3. İşin üstüne tıkla → en altta **Artifacts** → **Oyun-APK** indir.
4. İndirilen zip'i aç, içinden `app-debug.apk` çıkar.

### 4. Telefona yükle
- `app-debug.apk`'ya dokun → **Yükle** (bilinmeyen kaynaklara izin sorarsa
  onayla) → oyunu aç, oyna.

---

## Yeni bir oyun/güncelleme geldiğinde

Sadece 2. adımı tekrarla: `app/src/main/assets/index.html`'i yeni oyunun
koduyla değiştir, commit'le, Actions bitince yeni APK'yı indir. Uygulama adı
ve ikonunu değiştirmek istersen `app/src/main/res/values/strings.xml`
(`app_name`) ve `app/src/main/res/drawable/ic_launcher_foreground.xml`
dosyalarını düzenleyebilirsin.

---

## Notlar

- Uygulama tamamen çevrimdışı çalışır (WebView, assets içinden yükler,
  internete çıkmaz).
- Derleme her zaman **debug** APK üretir (imzasız, test/kişisel kullanım
  içindir) — Play Store'a yüklemek için ayrıca imzalama (release keystore)
  gerekir, bu proje şimdilik onu kapsamıyor.
- `applicationId` (`com.jarvis.gamewrapper`) her oyunda aynı kalıyor; aynı
  anda birden fazla oyunu telefonunda AYRI uygulamalar olarak tutmak
  istersen `app/build.gradle.kts` içindeki `applicationId`'yi her oyun için
  farklı bir isimle değiştirip ayrı ayrı derlemen gerekir.
